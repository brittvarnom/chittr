# Chittr microblogging platform

Chittr is a totally original, unique and non-plagiarised platform for microblogging. Users who sign up for an account
 can publish ‘Chits’ – short, textual based posts of no more than 141 characters. Users can also follow their friends
  and peers to keep updated with what their friends are Chitting about.