const convict = require('convict');

let config = convict({
    authToken: {
        format: String,
        default: 'X-Authorization'
    },
    db: {
        host: { // host, rather than hostname, as mysql connection string uses 'host'
            format: String,
            default: "mudfoot.doc.stu.mmu.ac.uk"
        },
        port: {
            format: Number,
            default: 6306
        },
        user: {
            format: String,
            default: 'YOUR_MUDFOOT_USERNAME'
        },
        password: {
            format: String,
            default: 'YOUR_MUDFOOT_PASSWORD'
        },
        database: {
            format: String,
            default: 'YOUR_MUDFOOT_USERNAME'
        },
        multipleStatements:{
            format: Boolean,
            default: true
        }
    }
});


module.exports = config;
